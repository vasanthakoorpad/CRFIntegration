<?php
/**
 * @package YM Member profile synchronization cron
 * @version 1.0,0
 */
 
/*
Plugin Name: YM Member profile synchronization cron
Plugin URI: Not published
Description: YM Member profile synchronization cron
Author: Satyam Gollapalli
Version: 1.0.0
Text Domain: Sync-member-profile-with-YM
*/
 
define('DISABLE_WP_CRON', true);


//Create the YourMembership XML request object.
function create_sa_xml($ym_call = '', $ym_callID = '000', $sessionID = NULL, $ym_callArgs = array(),$ym_custArgs1 = array(),$lnurl=NULL,$biography=NULL) {
	global $error;

/* YM API Credentials*/
define('API_ENDPOINT', 'https://api.yourmembership.com');
define('API_VERSION', '2.30');
define('API_KEY_PUBLIC', 'F6D16B47-EE3B-453F-8B7C-2C8E10488DAA');
define('API_SET_PASS_CODE', 'wprU89ihylc7');

  if (empty($ym_call)) {
    return '';
  }
  
  $doc = new DOMDocument('1.0', 'UTF-8');
  $doc->formatOutput = true;	// Human-readable XML. Good for debugging.
  
  $xml    = $doc->createElement('YourMembership');
  $ver    = $doc->createElement('Version', API_VERSION);
  $apiKey = $doc->createElement('ApiKey', API_KEY_PUBLIC);
  $callID = $doc->createElement('CallID', $ym_callID);
  $passCode = $doc->createElement('SaPasscode', API_SET_PASS_CODE);
  $call   = $doc->createElement('Call');
  
    
  $xml->appendChild($ver);
  $xml->appendChild($apiKey);
  $xml->appendChild($callID);
  
  if (isset($sessionID)) {
    $el = $doc->createElement('SessionID', $sessionID);
    $xml->appendChild($el);
  }
  
  
  
  $callAttr = $doc->createAttribute('Method');
  $callAttr->value = $ym_call;
  
  $call->appendChild($callAttr);
  
  if (count($ym_callArgs)) {
    foreach ($ym_callArgs as $key => $val) {
      // Make sure all call argument data are sanitized
      $el = $doc->createElement($key, sanitize_form_field($val));
      $call->appendChild($el);
    }
  }
  
  if($ym_call == "Sa.People.Profile.Update")
  {
    $xml->appendChild($passCode);
	$customfields = $doc->createElement('CustomFieldResponses');
	$call->appendChild($customfields);
  }

  if($ym_call == "Sa.People.All.GetIDs" || $ym_call == "Sa.People.Profile.Get"  || $ym_call == "Sa.Auth.Authenticate"  || $ym_call == "Sa.People.Profile.FindID" )
  {
	  $xml->appendChild($passCode);
  }
  
  
 //Practice Area
 if ( count($ym_custArgs1))
  {
	$customfield1 = $doc->createElement('CustomFieldResponse');
	
	$callcustAttr1 = $doc->createAttribute('FieldCode');
	$callcustAttr1->value = "PA1";
	
	$customfield1->appendChild($callcustAttr1);
	
	$values = $doc->createElement('Values');
	
	
	for ($i=0; $i<count($ym_custArgs1);$i++) {
      // Make sure all call argument data are sanitized
     $el1 = $doc->createElement("Value",sanitize_form_field($ym_custArgs1[$i]));
     $values->appendChild($el1);
    }
	$customfield1->appendChild($values);
	$customfields->appendChild($customfield1);
	
} 
 
//linkedin URL
if ( isset($lnurl))
  {
	$customfield1 = $doc->createElement('CustomFieldResponse');
	
	$callcustAttr1 = $doc->createAttribute('FieldCode');
	$callcustAttr1->value = "LIURL";
	
	$customfield1->appendChild($callcustAttr1);
	
	$values = $doc->createElement('Values');
	
	
	$el1 = $doc->createElement("Value",sanitize_form_field($lnurl));
    $values->appendChild($el1);
    
	$customfield1->appendChild($values);
	$customfields->appendChild($customfield1);
	
}

//Biography
if ( isset($biography))
  {
	$customfield1 = $doc->createElement('CustomFieldResponse');
	
	$callcustAttr1 = $doc->createAttribute('FieldCode');
	$callcustAttr1->value = "Bio";
	
	$customfield1->appendChild($callcustAttr1);
	
	$values = $doc->createElement('Values');
	
	
	$el1 = $doc->createElement("Value",sanitize_form_field($biography));
    $values->appendChild($el1);
    
	$customfield1->appendChild($values);
	$customfields->appendChild($customfield1);
	
}
 

 
  $xml->appendChild($call);
  $doc->appendChild($xml);
  
  
  return $doc->saveXML();
}





// Calls Sa.Members.Profile.Create : https://api.yourmembership.com/reference/2_30/Sa_Members_Profile_Create.htm
function getAddedModifiedPeoples() 
{

  $api_response = new stdClass();
  $api_response->ErrCode = 9001;
  
  // Create session 
  // Calls Session.Create: https://api.yourmembership.com/reference/2_30/Session_Create.htm
  //$api_response = get_api_response(create_xml('Session.Create', '001', NULL));
  
  // Authenticate submitted user credentials if the session created
  if (true) {
	
	//$sessionID = (string)$api_response->{"Session.Create"}->SessionID;
  
	$ts = date('Y-m-d H:i:s', strtotime('-330 minutes'));

	
	
	$api_response = get_api_response(create_sa_xml(
                        'Sa.People.All.GetIDs',
                        '009'.rand(),
						NULL,
                        array(
						  'Timestamp'=>$ts
						)
					));
   
   
	
	
	$modifiedIds = (array)$api_response->{"Sa.People.All.GetIDs"}->{"People"}->ID;
	
	
	return $modifiedIds;
  }
  
  return false;

}

//Get Member profile information
function getMemberInfo($uid)
{
	$api_response = NULL;
	
	$api_response = get_api_response(create_sa_xml(
                        'Sa.People.Profile.Get',
                        '010'.rand(),
						NULL,
                        array(
						  'ID'=>$uid
						)
					));
   
   
   return (array)$api_response->{"Sa.People.Profile.Get"};
	
}


 

function cron_task_hook($schedules){
    if(!isset($schedules["5min"])){
        $schedules["5min"] = array(
            'interval' => 25*60,
            'display' => __('Once every 5 minutes'));
    }
    if(!isset($schedules["30min"])){
        $schedules["30min"] = array(
            'interval' => 30*60,
            'display' => __('Once every 30 minutes'));
    }
    return $schedules;
}


add_filter('cron_schedules','cron_task_hook');


if (!wp_next_scheduled('cron_task_hook')) {
	wp_schedule_event( time(), '5min', 'cron_task_hook' );
}

add_action ( 'cron_task_hook', 'my_task_function' );

function my_task_function() {
	
	
$ym_user_modified_ids = getAddedModifiedPeoples();
 
 
 
 if($ym_user_modified_ids){
	   
	   
	foreach ($ym_user_modified_ids as $k => $v) {
	    
		unset($user);
		unset($api_response);
		$user = array();
	    $api_response = array();
		
		
		
		// Get the member info from YM & save to YM.csv
		$api_response = getMemberInfo($v);
		
		//complete member profile information- $user array will have complete profile information that require for synch meber profile in CRF website
		$user['EmailAddr'] = (string)$api_response['EmailAddr'];
		
		$user['NamePrefix'] = (string)$api_response['NamePrefix'];
		$user['FirstName'] = (string)$api_response['FirstName'];
		$user['LastName'] = (string)$api_response['LastName'];
		$user['Mobile'] = (string)$api_response['Mobile'];
		$user['EmpPhone'] = (string)$api_response['EmpPhone'];
		$user['Employer'] = (string)$api_response['Employer'];
		$user['Title'] = (string)$api_response['Title'];
		
		$user['EmpAddrLine1'] = (string)$api_response['EmpAddrLines'];	
		$user['EmpAddrLine2'] = "";
		$user['EmpCity'] = (string)$api_response['EmpCity'];
		$user['EmpPostalCode'] = (string)$api_response['EmpPostalCode'];
		$user['EmpLocation'] = (string)$api_response['EmpLocation'];
		$user['EmpCountry'] = (string)$api_response['EmpCountry'];
		$user['Username'] = (string)$api_response['Username'];
		$user['Password'] = (string)$api_response['PasswordHash'];
		$user['Membership'] = (string)$api_response['MemberTypeCode'];
		
		
		
		$custom_values = $api_response['CustomFieldResponses']->{"CustomFieldResponse"};
		
		for($i=0; $i<count($custom_values);$i++) {
			
			
			if( $custom_values[$i]['FieldCode'] == "PA1" )
			{
				//Practice Area(s) values
				$user['Practiceareas'] = (array)$custom_values[$i]->{"Values"}->Value;
			}
			
			if( $custom_values[$i]['FieldCode'] == "LIURL" )
			{
				//Linkedin URL
				$user['linkedinURL'] = (string)$custom_values[$i]->{"Values"}->Value;
			}
			
			if( $custom_values[$i]['FieldCode'] == "Bio" )
			{
				//Biography
				$user['Biography']  = (string)$custom_values[$i]->{"Values"}->Value;
			}
			
			
			if( $custom_values[$i]['FieldCode'] == "InSec" )
			{
				//Industry Sector
				$user['Insector']  = (string)$custom_values[$i]->{"Values"}->Value;
			}
			
			if( $custom_values[$i]['FieldCode'] == "OrgS" )
			{
				//Org Size
				$user['Orgsize']  = (string)$custom_values[$i]->{"Values"}->Value;
			}
			
			if( $custom_values[$i]['FieldCode'] == "keyu" )
			{
				//Key User
				$user['Keyuser']  = (string)$custom_values[$i]->{"Values"}->Value;
			}
			
			
		}
		
		
	    if ( $user['Username']  && $user['Password'] &&  $user['EmailAddr']) 
		{
	
			$member_id = FALSE;
			$user_id = FALSE;
			
			//Update or create crf site Member profile
			$member_id = ym_member_profille_update($user['Username'], $user['Password'] , $user);
		
			if($member_id)
			{
				$user['member_id'] = $member_id;
		
				//Update or create c crf site user profile
				$user_id = ym_user_profille_update($user['Username'], $user['Password'] , $user);
			}
	 	
			//update relationship claimed
			if($user_id)
			{
				
				$get_user_data = get_user_meta($member_id, $key = 'paupress_pp_relationship_claimed', $single = true);
		
				if (!in_array($user_id, $get_user_data))
				{
					$get_user_data[$user_id] = array("value" => $user_id ,"type" => "organization");
						
					update_user_meta_data($member_id,array("paupress_pp_relationship_claimed"=> $get_user_data));
				}
			}
			
	
			unset($get_user_data);
		//$get_user_data = get_user_meta($member_id, $key = '', $single = false);
		echo "User Profile Updated " .$user['Username']."</br>";
		

		} 
		 
	

	
	
	
	}

	
 }
 
 
 
 
}
 
?>